#include <stdio.h>

int main()
{
    int s,n;
    scanf("%d,%d",&s,&n);
    float v = s/n;
    printf("v =%f\n",v);
    return 0;
}

