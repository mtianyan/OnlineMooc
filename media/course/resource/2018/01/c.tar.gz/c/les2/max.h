int maxNum(int a, int b);
