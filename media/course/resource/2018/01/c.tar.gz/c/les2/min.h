int minNum(int a ,int b);
