#include <stdio.h>

int main(int argc,char* argv[])
{
    printf("argc is %d\n",argc);

    return 101;
}
