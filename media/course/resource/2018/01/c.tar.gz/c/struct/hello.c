#include <stdio.h>
#define R 10
#define M int main(
#define N(n) n*10
#define ADD(a,b) a+b

int add(int a,int b){
    return a+b;
}
typedef int tni;

M){
    tni  a = R;
    int b =N(a);
    int c =add(a,b);
    int d =ADD(a,b);
    int e = ADD(a,b) * ADD(a,b);

    printf("e = %d\n",e);
    printf("b = %d\n",b);
    printf("a =%d\n",a);
    printf("c =%d\n",c);
    printf("d =%d\n",d);
    printf("hello,world!\n");
    return 0;
}
