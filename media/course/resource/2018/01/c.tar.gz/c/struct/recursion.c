#include <stdio.h>
int func(int a)
{
    int r =0;
    if(a<0){
	printf("error");
}else if(a==0 | a==1){
    return 1;
}else{
    r =a *func(a-1);
    return r;
}

}

int main()
{
   int a =0;
   printf("please input the num:");
   scanf("%d",&a);
   int r = func(a);
   printf("the result is %d",r);
   return 0;
}
