#include <stdio.h>

int main()
{
   // & | ^ ~ << >>

   int a =9;//1001
   int b =5;//0101

   int c =a|b;//1101

   //int d =b&1;//0100
   printf("%d\n",c);
   //printf("%d\n",d);
   return 0;
}
