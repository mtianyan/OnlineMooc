from django.apps import AppConfig


class XadminApiConfig(AppConfig):
    name = 'tyadmin_api'
