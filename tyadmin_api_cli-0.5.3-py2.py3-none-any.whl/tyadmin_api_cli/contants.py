MAIN_DISPLAY = "$显示字段$"
MAIN_AVATAR = "$显示头像$"
MAIN_PIC = "$显示图片$"
SYS_LABELS = ['contenttypes','auth']