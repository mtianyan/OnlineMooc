ADAPTER_DICT = {
    'django_celery_beat': {
        'PeriodicTask': ['task']
    }
}
