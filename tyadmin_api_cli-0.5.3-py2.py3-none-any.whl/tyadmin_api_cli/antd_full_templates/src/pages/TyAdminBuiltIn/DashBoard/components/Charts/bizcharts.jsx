import * as BizChart from 'bizcharts';

export default BizChart;
